<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['name']        = __( 'Blog Posts', 'fw' );
$manifest['description'] = __( 'Blog Posts', 'fw' );
$manifest['version'] = '1.0.2';
$manifest['display'] = false;
$manifest['standalone'] = true;

$manifest['github_update'] = 'ThemeFuse/Unyson-Blog-Extension';
